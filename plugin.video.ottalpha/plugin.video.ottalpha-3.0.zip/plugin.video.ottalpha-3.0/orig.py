import urllib as OO0OOO0O00OOO0O00 ,urllib2 as OO0O0OO0OOOO00OOO ,sys as O0OOO000O0O0O0O00 ,xbmcplugin as OO0O000O0OOOOOO0O ,xbmcgui as OO0O000000OOOOO00 ,xbmcaddon as O00O00OOOOOOO0OOO ,xbmc as OO00O0O0OOOOOOOO0 ,os as O0O0OOOO00000OOO0 ,json as O0O00O0000000OO0O ,re as OOOOO0OOOOO0O00O0 #line:1
import common as O000O0O0OO0OOOO00 ,xbmcvfs as OO00O00OO0OO0OOO0 ,zipfile as OOO000O000O000O0O ,downloader as O00OO0OOO0OOO0000 ,extract as OOO0OO0O0OOOOO0O0 #line:2
import GoDev as O0O0OOOO0O00000O0 #line:3
from datetime import datetime as OO0OOOOO0O00000OO ,timedelta as OOO000OOO0000O0O0 #line:4
import base64 as O00O0OOO0O00O00O0 ,time as O0000OOOO0O00000O #line:5
AddonID ='plugin.video.ottalpha'#line:7
Addon =O00O00OOOOOOO0OOO .Addon (AddonID )#line:8
ADDON =O00O00OOOOOOO0OOO .Addon (id ='plugin.video.ottalpha')#line:9
Username =OO0O000O0OOOOOO0O .getSetting (int (O0OOO000O0O0O0O00 .argv [1 ]),'Username')#line:11
Password =OO0O000O0OOOOOO0O .getSetting (int (O0OOO000O0O0O0O00 .argv [1 ]),'Password')#line:12
ServerURL ="http://otttv.co:2095/get.php?username=%s&password=%s&type=m3u&output=hls"%(Username ,Password ,)#line:13
AccLink ="http://otttv.co:2095/panel_api.php?username=%s&password=%s"%(Username ,Password ,)#line:14
addonDir =Addon .getAddonInfo ('path').decode ("utf-8")#line:15
Images =OO00O0O0OOOOOOOO0 .translatePath (O0O0OOOO00000OOO0 .path .join ('special://home','addons',AddonID ,'resources/'));#line:16
addon_data_dir =O0O0OOOO00000OOO0 .path .join (OO00O0O0OOOOOOOO0 .translatePath ("special://userdata/addon_data").decode ("utf-8"),AddonID )#line:17
if not O0O0OOOO00000OOO0 .path .exists (addon_data_dir ):#line:18
    O0O0OOOO00000OOO0 .makedirs (addon_data_dir )#line:19
def OPEN_URL (O0OOO0000O00OO0OO ):#line:20
    OOO0OO0O00O00000O =OO0O0OO0OOOO00OOO .Request (O0OOO0000O00OO0OO )#line:21
    OOO0OO0O00O00000O .add_header ('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')#line:22
    OO00O00O00O000000 =OO0O0OO0OOOO00OOO .urlopen (OOO0OO0O00O00000O )#line:23
    OOOOOO0O0000O00O0 =OO00O00O00O000000 .read ()#line:24
    OO00O00O00O000000 .close ()#line:25
    return OOOOOO0O0000O00O0 #line:26
def Open_URL (O0O0OOO0OO0OO0O00 ):#line:27
        OO0OOO0OOOO0O00O0 =OO0O0OO0OOOO00OOO .Request (url )#line:28
        OO0OOO0OOOO0O00O0 .add_header ('User-Agent','Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100101 Firefox/11.0')#line:30
        OO000OO0OO000OOOO =OO0O0OO0OOOO00OOO .urlopen (OO0OOO0OOOO0O00O0 )#line:31
        OO00OO0OO0OOO0000 =OO000OO0OO000OOOO .read ()#line:32
        OO000OO0OO000OOOO .close ()#line:33
        return OO00OO0OO0OOO0000 #line:34
def MainMenu ():#line:35
        AddDir ('My Account',AccLink ,1 ,Images +'MyAcc.png')#line:36
        AddDir ('Live TV','url',2 ,Images +'Live TV.png')#line:37
        AddDir ('Movies (Coming Soon)','Movies',8 ,Images +'movies.png')#line:38
        AddDir ('TVShows (Coming Soon)','TVshows',9 ,Images +'tvshows.png')#line:39
        AddDir ('Extras','Extras',5 ,Images +'extras.png')#line:40
        AddDir ('Clear Cache','Clear Cache',7 ,Images +'cache.png')#line:41
        AddDir ('Settings','settings',4 ,Images +'settings.png')#line:42
def LiveTv (OOOO0OO00000OOOO0 ):#line:43
    O0OO0OO000O0OOOO0 =O000O0O0OO0OOOO00 .m3u2list (ServerURL )#line:44
    for OO0OOOO0O00OOO000 in O0OO0OO000O0OOOO0 :#line:45
        O0OO0O00O00000OOO =O000O0O0OO0OOOO00 .GetEncodeString (OO0OOOO0O00OOO000 ["display_name"])#line:46
        AddDir (O0OO0O00O00000OOO ,OO0OOOO0O00OOO000 ["url"],3 ,iconimage ,isFolder =False )#line:47
def MyAccDetails (O0OOO00OO000O00OO ):#line:48
        OOO00O0O0OO00OOOO =Open_URL (O0OOO00OO000O00OO )#line:49
        O000OO00O0O0O0000 =OOOOO0OOOOO0O00O0 .compile ('"username":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:50
        OO000OOOO000O0000 =OOOOO0OOOOO0O00O0 .compile ('"status":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:51
        OOO00OOO00OOOOOO0 =OOOOO0OOOOO0O00O0 .compile ('"exp_date":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:52
        O0OOOOOO0OO0OO0OO =OOOOO0OOOOO0O00O0 .compile ('"active_cons":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:53
        O0000O0O00O0O0O0O =OOOOO0OOOOO0O00O0 .compile ('"created_at":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:54
        OOOO0OO0O0O0OO00O =OOOOO0OOOOO0O00O0 .compile ('"max_connections":"(.+?)"').findall (OOO00O0O0OO00OOOO )#line:55
        OO0O000O000O0O0OO =OOOOO0OOOOO0O00O0 .compile ('"is_trial":"1"').findall (OOO00O0O0OO00OOOO )#line:56
        for O0OOO00OO000O00OO in O000OO00O0O0O0000 :#line:57
                AddAccInfo ('My Account Information','','',Images +'MyAcc.png')#line:58
                AddAccInfo ('Username:  %s'%(O0OOO00OO000O00OO ),'','',Images +'MyAcc.png')#line:59
        for O0OOO00OO000O00OO in OO000OOOO000O0000 :#line:60
                AddAccInfo ('Status:  %s'%(O0OOO00OO000O00OO ),'','',Images +'MyAcc.png')#line:61
        for O0OOO00OO000O00OO in O0000O0O00O0O0O0O :#line:62
                O0OOO0000O0OOO0OO =OO0OOOOO0O00000OO .fromtimestamp (float (O0000O0O00O0O0O0O [0 ]))#line:63
                O0OOO0000O0OOO0OO .strftime ('%Y-%m-%d %H:%M:%S')#line:64
                AddAccInfo ('Created:  %s'%(O0OOO0000O0OOO0OO ),'','',Images +'MyAcc.png')#line:65
        for O0OOO00OO000O00OO in OOO00OOO00OOOOOO0 :#line:66
                O0OOO0000O0OOO0OO =OO0OOOOO0O00000OO .fromtimestamp (float (OOO00OOO00OOOOOO0 [0 ]))#line:67
                O0OOO0000O0OOO0OO .strftime ('%Y-%m-%d %H:%M:%S')#line:68
                AddAccInfo ('Expires:  %s'%(O0OOO0000O0OOO0OO ),'','',Images +'MyAcc.png')#line:69
        for O0OOO00OO000O00OO in O0OOOOOO0OO0OO0OO :#line:70
                AddAccInfo ('Active Connection:  %s'%(O0OOO00OO000O00OO ),'','',Images +'MyAcc.png')#line:71
        for O0OOO00OO000O00OO in OOOO0OO0O0O0OO00O :#line:72
                AddAccInfo ('Max Connection:  %s'%(O0OOO00OO000O00OO ),'','',Images +'MyAcc.png')#line:73
        for O0OOO00OO000O00OO in OO0O000O000O0O0OO :#line:74
                AddAccInfo ('Trial: Yes','','',Images +'MyAcc.png')#line:75
def PlayUrl (OO00O0O0O0OO00000 ,O00O0O0O00OOO0OOO ,iconimage =None ):#line:77
        _O0O0OO0O0O0O0OOOO =OO00O0O0O0OO00000 #line:78
        OO0O0000OO0O000O0 =O000O0O0OO0OOOO00 .m3u2list (ServerURL )#line:79
        for OO00O000OOO0000OO in OO0O0000OO0O000O0 :#line:80
            OO00O0O0O0OO00000 =O000O0O0OO0OOOO00 .GetEncodeString (OO00O000OOO0000OO ["display_name"])#line:81
            OOO00OO0OOOOO000O =OO00O000OOO0000OO ["url"]#line:82
            if _O0O0OO0O0O0O0OOOO in OO00O0O0O0OO00000 :#line:83
                O000O0O0O0O0000O0 =OO0O000000OOOOO00 .ListItem (path =OOO00OO0OOOOO000O ,thumbnailImage =iconimage )#line:84
                O000O0O0O0O0000O0 .setInfo (type ="Video",infoLabels ={"Title":OO00O0O0O0OO00000 })#line:85
                OO0O000O0OOOOOO0O .setResolvedUrl (int (O0OOO000O0O0O0O00 .argv [1 ]),True ,O000O0O0O0O0000O0 )#line:86
def AddAccInfo (O0O000O0OOO0O0O0O ,O0OO0O00O0O0OO0OO ,O00O00O0OOOOOOO00 ,OOO00O00O0OOO0000 ):#line:87
        OOOOO0OO0O0O000O0 =O0OOO000O0O0O0O00 .argv [0 ]+"?url="+OO0OOO0O00OOO0O00 .quote_plus (O0OO0O00O0O0OO0OO )+"&mode="+str (O00O00O0OOOOOOO00 )+"&name="+OO0OOO0O00OOO0O00 .quote_plus (O0O000O0OOO0O0O0O )#line:88
        O000OO00OO00O0OO0 =True #line:89
        OOO0O0OO00O00OO0O =OO0O000000OOOOO00 .ListItem (O0O000O0OOO0O0O0O ,iconImage ="DefaultFolder.png",thumbnailImage =OOO00O00O0OOO0000 )#line:90
        OOO0O0OO00O00OO0O .setInfo (type ="Video",infoLabels ={"Title":O0O000O0OOO0O0O0O })#line:91
        O000OO00OO00O0OO0 =OO0O000O0OOOOOO0O .addDirectoryItem (handle =int (O0OOO000O0O0O0O00 .argv [1 ]),url =OOOOO0OO0O0O000O0 ,listitem =OOO0O0OO00O00OO0O ,isFolder =False )#line:92
def AddDir (OO0O00000OOO00000 ,OOO0O0000000000O0 ,O00O000OOO0O0O0O0 ,O000OO00OOOOO00O0 ,description ="",isFolder =True ,background =None ):#line:93
    O0O00000000000O0O =O0OOO000O0O0O0O00 .argv [0 ]+"?url="+OO0OOO0O00OOO0O00 .quote_plus (OOO0O0000000000O0 )+"&mode="+str (O00O000OOO0O0O0O0 )+"&name="+OO0OOO0O00OOO0O00 .quote_plus (OO0O00000OOO00000 )+"&iconimage="+OO0OOO0O00OOO0O00 .quote_plus (O000OO00OOOOO00O0 )+"&description="+OO0OOO0O00OOO0O00 .quote_plus (description )#line:94
    O00O00O000OO0000O =O0OOO000O0O0O0O00 .argv [0 ]+"?url=None&mode="+str (O00O000OOO0O0O0O0 )+"&name="+OO0OOO0O00OOO0O00 .quote_plus (OO0O00000OOO00000 )+"&iconimage="+OO0OOO0O00OOO0O00 .quote_plus (O000OO00OOOOO00O0 )+"&description="+OO0OOO0O00OOO0O00 .quote_plus (description )#line:95
    O0OOO00OOO000OOO0 =OO0O000000OOOOO00 .ListItem (OO0O00000OOO00000 ,iconImage =O000OO00OOOOO00O0 ,thumbnailImage =O000OO00OOOOO00O0 )#line:97
    O0OOO00OOO000OOO0 .setInfo (type ="Video",infoLabels ={"Title":OO0O00000OOO00000 ,"Plot":description })#line:98
    O0OOO00OOO000OOO0 .setProperty ('IsPlayable','true')#line:99
    OO0O000O0OOOOOO0O .addDirectoryItem (handle =int (O0OOO000O0O0O0O00 .argv [1 ]),url =O0O00000000000O0O ,listitem =O0OOO00OOO000OOO0 ,isFolder =isFolder )#line:100
def Get_Params ():#line:101
    O0000O00OO0OO000O =[]#line:102
    O0OOO0O0OOO0OOO00 =O0OOO000O0O0O0O00 .argv [2 ]#line:103
    if len (O0OOO0O0OOO0OOO00 )>=2 :#line:104
        OOO0OO0000OOO00OO =O0OOO000O0O0O0O00 .argv [2 ]#line:105
        O0O0O0OOOO00O0OOO =OOO0OO0000OOO00OO .replace ('?','')#line:106
        if (OOO0OO0000OOO00OO [len (OOO0OO0000OOO00OO )-1 ]=='/'):#line:107
            OOO0OO0000OOO00OO =OOO0OO0000OOO00OO [0 :len (OOO0OO0000OOO00OO )-2 ]#line:108
        O0OOO0OOO0OO0O0O0 =O0O0O0OOOO00O0OOO .split ('&')#line:109
        O0000O00OO0OO000O ={}#line:110
        for OOOOOO000O0OOOO00 in range (len (O0OOO0OOO0OO0O0O0 )):#line:111
            OO00000O00000OOO0 ={}#line:112
            OO00000O00000OOO0 =O0OOO0OOO0OO0O0O0 [OOOOOO000O0OOOO00 ].split ('=')#line:113
            if (len (OO00000O00000OOO0 ))==2 :#line:114
                O0000O00OO0OO000O [OO00000O00000OOO0 [0 ].lower ()]=OO00000O00000OOO0 [1 ]#line:115
    return O0000O00OO0OO000O #line:116
def correctPVR ():#line:118
	O0O000000OO0OOO0O =O00O00OOOOOOO0OOO .Addon ('plugin.video.ottalpha')#line:120
	O00OOO0OO00O00000 =O0O000000OO0OOO0O .getSetting (id ='Username')#line:121
	OOOO0000O00000OOO =O0O000000OO0OOO0O .getSetting (id ='Password')#line:122
	OO0OOOO000O000OOO ='{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'#line:123
	OOOOOO0000O0O0OOO ='{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'#line:124
	OOOO00O00000O0000 ='{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'#line:125
	OOO00O00OOOOO0O00 ="http://otttv.co:2095/get.php?username="+O00OOO0OO00O00000 +"&password="+OOOO0000O00000OOO +"&type=m3u_plus&output=ts"#line:126
	OOO0OO0000O00O0O0 ="http://otttv.co:2095/xmltv.php?username="+O00OOO0OO00O00000 +"&password="+OOOO0000O00000OOO +"&type=m3u_plus&output=ts"#line:127
	OO00O0O0OOOOOOOO0 .executeJSONRPC (OO0OOOO000O000OOO )#line:129
	OO00O0O0OOOOOOOO0 .executeJSONRPC (OOOOOO0000O0O0OOO )#line:130
	OO00O0O0OOOOOOOO0 .executeJSONRPC (OOOO00O00000O0000 )#line:131
	OOO00OO0O00OO000O =O00O00OOOOOOO0OOO .Addon ('pvr.iptvsimple')#line:133
	OOO00OO0O00OO000O .setSetting (id ='m3uUrl',value =OOO00O00OOOOO0O00 )#line:134
	OOO00OO0O00OO000O .setSetting (id ='epgUrl',value =OOO0OO0000O00O0O0 )#line:135
	OOO00OO0O00OO000O .setSetting (id ='m3uCache',value ="false")#line:136
	OOO00OO0O00OO000O .setSetting (id ='epgCache',value ="false")#line:137
	OO000OOO0O00O00O0 =OO0O000000OOOOO00 .Dialog ().ok ("[COLOR white]PVR SETUP DONE[/COLOR]",'[COLOR white]We\'ve copied your OTTTV to the PVR Guide[/COLOR]',' ','[COLOR white]This includes the EPG please allow time to populate now click launch PVR[/COLOR]')#line:138
def LaunchPVR ():#line:141
	OO00O0O0OOOOOOOO0 .executebuiltin ('ActivateWindow(TVGuide)')#line:142
def OpenSettings ():#line:144
    ADDON .openSettings ()#line:145
    MainMenu ()#line:146
def Clear_Cache ():#line:147
    OOO000OO0OO000O0O =OO0O000000OOOOO00 .Dialog ().yesno ('Clear your Cache?','If you still cant see your account after ok button is clicked your details are incorrect',nolabel ='Cancel',yeslabel ='OK')#line:148
    if OOO000OO0OO000O0O ==1 :#line:149
        O0O0OOOO0O00000O0 .Wipe_Cache ()#line:150
def wizard2 ():#line:152
    OO0O00O0OOOO00O0O =gettextdata ('http://fix4u.tech/ottserver/update.txt')#line:153
    O0O0000OOO00O00O0 =OO0O000000OOOOO00 .Dialog ()#line:154
    O0O0000OOO00O00O0 .ok ("Sporting Info",OO0O00O0OOOO00O0O ,"","")#line:155
def wizard3 ():#line:157
	OO0OO0O00O00OOO00 =OO0O000000OOOOO00 .Dialog ()#line:158
	O00OO0O0OO000O0O0 =OO00O0O0OOOOOOOO0 .translatePath ('special://home/addons')#line:159
	O0O0O00OO00000O0O =O0O0OOOO00000OOO0 .listdir (O00OO0O0OO000O0O0 )#line:160
	if 'script.ivueguide'in O0O0O00OO00000O0O :#line:161
		OO00O0O0OOOOOOOO0 .executebuiltin ('RunAddon(script.ivueguide)')#line:162
	else :#line:163
		OO0OO0O00O00OOO00 .ok ('Not Installed','You need ivue guide in order to use this')#line:164
def addXMLMenu (O0O00OOOOOOO0O0O0 ,OO0OO000OO0O00OO0 ,O0O0OO0O000OO0O00 ,OOO00000OOO000OOO ,O0O000O000O00OOO0 ,O0O00OOOOO00O00OO ):#line:166
        OO000O0O0O00OO0OO =O0OOO000O0O0O0O00 .argv [0 ]+"?url="+OO0OOO0O00OOO0O00 .quote_plus (OO0OO000OO0O00OO0 )+"&mode="+str (O0O0OO0O000OO0O00 )+"&name="+OO0OOO0O00OOO0O00 .quote_plus (O0O00OOOOOOO0O0O0 )+"&iconimage="+OO0OOO0O00OOO0O00 .quote_plus (OOO00000OOO000OOO )+"&fanart="+OO0OOO0O00OOO0O00 .quote_plus (O0O000O000O00OOO0 )+"&description="+OO0OOO0O00OOO0O00 .quote_plus (O0O00OOOOO00O00OO )#line:167
        OO0OOOO0OOOOOOO00 =True #line:168
        O0000OOO00OOO0OOO =OO0O000000OOOOO00 .ListItem (O0O00OOOOOOO0O0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =OOO00000OOO000OOO )#line:169
        O0000OOO00OOO0OOO .setInfo (type ="Video",infoLabels ={"Title":O0O00OOOOOOO0O0O0 ,"Plot":O0O00OOOOO00O00OO })#line:170
        O0000OOO00OOO0OOO .setProperty ("Fanart_Image",O0O000O000O00OOO0 )#line:171
        OO0OOOO0OOOOOOO00 =OO0O000O0OOOOOO0O .addDirectoryItem (handle =int (O0OOO000O0O0O0O00 .argv [1 ]),url =OO000O0O0O00OO0OO ,listitem =O0000OOO00OOO0OOO ,isFolder =False )#line:172
        return OO0OOOO0OOOOOOO00 #line:173
def ExtraMenu ():#line:174
    OO0OO00O00O000000 =OPEN_URL ('http://46.105.35.189/development/xml/toolboxextras.xml').replace ('\n','').replace ('\r','')#line:175
    OO0O0O0O0O0OOOOO0 =OOOOO0OOOOO0O00O0 .compile ('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO00O00O000000 )#line:176
    for OO00O0OO0O0000O00 ,O0O0O0OOO00OOOO0O ,OOOO0OO0O0O000000 ,O0O000O0OO0000OO0 ,O0O00O0OO00O00O0O in OO0O0O0O0O0OOOOO0 :#line:177
        addXMLMenu (OO00O0OO0O0000O00 ,O0O0O0OOO00OOOO0O ,6 ,OOOO0OO0O0O000000 ,O0O000O0OO0000OO0 ,O0O00O0OO00O00O0O )#line:178
def Movies ():#line:179
	O000O0000OO00O0O0 =OO0O000000OOOOO00 .Dialog ()#line:180
	OOO0OOO00O0O00O00 =OO00O0O0OOOOOOOO0 .translatePath ('special://home/addons')#line:181
	O0O00OOOO00O0OO0O =O0O0OOOO00000OOO0 .listdir (OOO0OOO00O0O00O00 )#line:182
	if 'plugin.program.fixtures'in O0O00OOOO00O0OO0O :#line:183
		OO00O0O0OOOOOOOO0 .executebuiltin ('RunAddon(plugin.program.fixtures)')#line:184
	else :#line:185
		O000O0000OO00O0O0 .ok ('Not Installed','You need extended info to use this')#line:186
def TVShows ():#line:188
	O0000O00OOO000OO0 =OO0O000000OOOOO00 .Dialog ()#line:189
	O00000OO00OO0O00O =OO00O0O0OOOOOOOO0 .translatePath ('special://home/addons')#line:190
	O0OOOO000O0OOOOOO =O0O0OOOO00000OOO0 .listdir (O00000OO00OO0O00O )#line:191
	if 'plugin.program.mtvguidepro'in O0OOOO000O0OOOOOO :#line:192
		OO00O0O0OOOOOOOO0 .executebuiltin ('RunAddon(plugin.program.mtvguidepro)')#line:193
	else :#line:194
		O0000O00OOO000OO0 .ok ('Not Installed','You need mayfair pro guide in order to use this you can get it from here http://mayfairguides.com/pro')#line:195
def gettextdata (OOOOO0O0O00O00O00 ):#line:197
    mayfair_show_busy_dialog ()#line:198
    try :#line:199
        O0000OO00O000OOO0 =OO0O0OO0OOOO00OOO .Request (OOOOO0O0O00O00O00 )#line:200
        OO0000OO00OOOOO00 =OO0O0OO0OOOO00OOO .urlopen (O0000OO00O000OOO0 )#line:201
        O0O00OO0OO0OOO000 =OO0000OO00OOOOO00 .read ()#line:202
        OO0000OO00OOOOO00 .close ()#line:203
        mayfair_hide_busy_dialog ()#line:204
        if O0O00OO0OO0OOO000 =='':#line:205
            O0O00OO0OO0OOO000 ='No message to display, please check back later!'#line:206
        return O0O00OO0OO0OOO000 #line:207
    except :#line:208
        import sys as OO0OOOO0O0OOO0000 #line:209
        import traceback as OOOOOOOO000OOOO00 #line:210
        (OOOOOO0OOOOOO0O0O ,O00O00O0000O00O00 ,OOOOO0OOO0OO0OO0O )=OO0OOOO0O0OOO0000 .exc_info ()#line:211
        OOOOOOOO000OOOO00 .print_exception (OOOOOO0OOOOOO0O0O ,O00O00O0000O00O00 ,OOOOO0OOO0OO0OO0O )#line:212
        mayfair_hide_busy_dialog ()#line:213
        O0O00000OOOOOO0O0 =OO0O000000OOOOO00 .Dialog ()#line:214
        O0O00000OOOOOO0O0 .ok ("Error!","Error connecting to server!","","Please try again later.")#line:215
def mayfair_show_busy_dialog ():#line:217
    OO00O0O0OOOOOOOO0 .executebuiltin ('ActivateWindow(10138)')#line:218
def mayfair_hide_busy_dialog ():#line:220
    OO00O0O0OOOOOOOO0 .executebuiltin ('Dialog.Close(10138)')#line:221
    while OO00O0O0OOOOOOOO0 .getCondVisibility ('Window.IsActive(10138)'):#line:222
        OO00O0O0OOOOOOOO0 .sleep (100 )#line:223
params =Get_Params ()#line:228
url =None #line:229
name =None #line:230
mode =None #line:231
iconimage =None #line:232
description =None #line:233
try :url =OO0OOO0O00OOO0O00 .unquote_plus (params ["url"])#line:235
except :pass #line:236
try :name =OO0OOO0O00OOO0O00 .unquote_plus (params ["name"])#line:237
except :pass #line:238
try :iconimage =OO0OOO0O00OOO0O00 .unquote_plus (params ["iconimage"])#line:239
except :pass #line:240
try :mode =int (params ["mode"])#line:241
except :pass #line:242
try :description =OO0OOO0O00OOO0O00 .unquote_plus (params ["description"])#line:243
except :pass #line:244
if mode ==7 :#line:246
	Clear_Cache ()#line:247
elif mode ==8 :#line:248
	Movies ()#line:249
elif mode ==9 :#line:250
	TVShows ()#line:251
elif mode ==1 :#line:252
    MyAccDetails (url )#line:253
elif mode ==2 :#line:254
    LiveTv (url )#line:255
elif mode ==3 :#line:256
    PlayUrl (name ,url ,iconimage )#line:257
elif mode ==4 :#line:258
	OpenSettings ()#line:259
elif mode ==5 :#line:260
	ExtraMenu ()#line:261
elif mode ==6 :#line:262
	wizard2 ()#line:263
elif mode ==10 :#line:264
	wizard3 ()#line:265
elif mode ==11 :#line:266
	correctPVR ()#line:267
elif mode ==12 :#line:268
	LaunchPVR ()
#e9015584e6a44b14988f13e2298bcbf9

